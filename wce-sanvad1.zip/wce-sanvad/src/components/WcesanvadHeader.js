

import React from 'react'
import { Avatar} from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import FeaturedPlayListIcon from '@mui/icons-material/FeaturedPlayList';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import PeopleOutlineIcon from '@mui/icons-material/PeopleOutline';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';

import './css/Wceheader.css'
// import { selectUser } from '../userSlice';
// import db,{ auth } from '../firebase';
// import { useSelector } from "react-redux";
// import { useState } from 'react';





function WcesanvadHeader() {
  
  return (
    <div className="qHeader">
      <div className="qHeader-content">
        <div className="qHeader__logo">
          <img
            src="../images/logo.png"
            alt="logo"
          />
        </div>
        <div className="qHeader__icons">
          <div className="qHeader__icon">
            <HomeIcon />
          </div>
          <div className="qHeader__icon">
            <FeaturedPlayListIcon />
          </div>
          <div className="qHeader__icon">
            <AssignmentTurnedInIcon/>
          </div>
          <div className="qHeader__icon">
            <PeopleOutlineIcon />
          </div>
          <div className="qHeader__icon">
            <NotificationsNoneIcon />
          </div>
        </div>
        <div className="qHeader__input">
          <SearchOutlinedIcon />
          <input type="text" placeholder="Search questions" />
        </div>
        <div className="qHeader__Rem">
          <Avatar />
      </div>
      
         

    </div>
    </div>
    
    
  );
}

export default WcesanvadHeader;
