import React from 'react'
import "./css/SidebarOptions.css";
import SchoolIcon from '@mui/icons-material/School';
import SportsCricketIcon from '@mui/icons-material/SportsCricket';
import GroupsIcon from '@mui/icons-material/Groups';
import GiteIcon from '@mui/icons-material/Gite';
import FormatAlignJustifyOutlinedIcon from '@mui/icons-material/FormatAlignJustifyOutlined';
function SidebarOptions() {
  return (
    <div className='sidebarOptions'>
     <div className='sidebarOption'>
      <SchoolIcon/>
      
      <p>Academics</p>
      
     </div>

     <div className='sidebarOption'>
     <SportsCricketIcon/>
        
      <p>Sports</p>
     </div>

     <div className='sidebarOption'>
     <GroupsIcon/>
     
      <p>Club Services</p>
     </div>

     <div className='sidebarOption'>
     <GiteIcon/>
     
      <p>Hostels</p>
     </div>

     <div className='sidebarOption'>
      <FormatAlignJustifyOutlinedIcon/>
     
      <p>Others</p>
     </div>
    </div>
  )
}

export default SidebarOptions
