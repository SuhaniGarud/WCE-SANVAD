import React from 'react'
import Wcesanvadbox from './Wcesanvadbox'
import './css/Feed.css';
import Post from './Post';

function Feed() {
  return (
    <div className='feed'>
     <Wcesanvadbox/>
     <Post/>
     <Post/>
     <Post/>
     <Post/>
     <Post/>
    </div>
  )
}

export default Feed
