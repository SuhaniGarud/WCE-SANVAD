import React from 'react'
import Feed from './Feed.js';
import Sidebar from './Sidebar';
import WcesanvadHeader from './WcesanvadHeader';
import "./css/Wcesanvad.css";
import Suggestionbox from './Suggestionbox.js';




function Wcesanvad() {
  return (
    <div className='WCE_sanvad'>
      
    <WcesanvadHeader />
    
    <div className ='wcesanvad__contents'>
    <Sidebar />
           <div className='wcesanvad'>
            
            <Feed />
          
           </div>
     <Suggestionbox/>      
    </div>
       
    </div>
  );
}

export default Wcesanvad;
