import { Avatar } from '@mui/material'

import React from 'react'

import './css/Wcesanvadbox.css';
export default function Wcesanvadbox() {
  // const user = useSelector(selectUser)
  return (
    <div className='wcesanvadBox'>
       <div className='wcesanvadBox__Info'>
      <Avatar />
      {/* <h5>{user.displayName}</h5> */}
      </div>
      <div className='wcesanvadBox__sanvad'>
      <p>Ask your Question here...</p>
      </div>
    </div>
  )
}
