import React from 'react'
import './css/Suggestionbox__contents.css'
function Suggestionbox__contents() {
  return (
    <div className='Suggestionbox__contents'>
      <div className='Suggestionbox__contents'>
      <h8>Post your suggestions here</h8>
      </div>
    </div>
  )
}

export default Suggestionbox__contents
