import React from 'react'
import Suggestionbox__contents from './Suggestionbox__contents';
import MoveToInboxIcon from '@mui/icons-material/MoveToInbox';
import './css/Suggestionbox.css'

function Suggestionbox() {
  return (
    <div className='Suggestionbox'>
       <div className='Suggestionbox__header'>
      <h3>Suggestion Box</h3>
      <div className='icon'>
      <MoveToInboxIcon/>
      </div>
      </div>
      <div className='Suggestionbox__contents'>
      <Suggestionbox__contents/>
      </div>
    </div>
  )
}

export default Suggestionbox
