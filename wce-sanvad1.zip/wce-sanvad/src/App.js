
import React from "react";
import Wcesanvad from './components/Wcesanvad';
import './App.css';
// import { login, logout, selectUser } from './userSlice';

// import { useDispatch, useSelector } from 'react-redux';
// import Login from './components/Auth/Login';
// import { useEffect } from 'react';
// import { auth } from './firebase';
function App() {
<Wcesanvad/>
  

  return<div className="App">
      {
        <Wcesanvad/>
      }
     </div>;

    
  
}

export default App;

